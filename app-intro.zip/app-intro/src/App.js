import logo from './logo.svg';
import './App.css';
import Example from './Example'
import Usuarios from './Usuarios';
function App() {
  return (
    <div className="App">
       <Example/> 
       <br/>   
       <Usuarios/>

    </div>
  );
}

export default App;
